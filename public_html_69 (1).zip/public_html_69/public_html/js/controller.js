app.controller('mainCtrl', function($scope, $ionicPopup, $timeout, $location, $http) {
    $scope.user = {};
    $scope.popup = {};
    $scope.user.emailId = "";
    $scope.user.password = "";
    $scope.valid = "false";
    $scope.logIn = function() {

        $location.path("/dashboard/notification");
//        alert($scope.user.emailId);
//        $.ajax({
//            type: "POST",
//            url: "http://172.24.49.211:8080/TailoringApplication_/LoginServlet",
////            dataType: 'jsonp',
//            data: {emailId: $scope.user.emailId, password: $scope.user.password},
//            success: function (data) {
//                var logIn = JSON.parse(data);
//                if (logIn.login === "valid") {
//                    $scope.valid = "true";
//                    $scope.logInPopUp.close();
////                    $location.path("/newOrder");
//                }
//            },
//            error: function () {
//                alert("Error");
//            }
//        });
    };
//    $scope.logInPopUp = function() {
//        $ionicPopup.show({
//            template: $('<div>' +
//                    '' +
//                    '' +
//                    '<div class="input-field">' +
//                    '<i class="mdi-communication-email prefix"></i>' +
//                    '<input id="email" type="text" ng-model="user.emailId">' +
//                    '<label class="teal-text text-lighten-2" for="email">Email ID</label>' +
//                    '</div>' +
//                    '<div class="input-field">' +
//                    '<i class="mdi-action-lock prefix"></i>' +
//                    '<input id="password" type="password" ng-model="user.password">' +
//                    '<label class="teal-text text-lighten-2" for="password">Password</label>' +
//                    '</div>' +
//                    '<button class="button button-full button-balanced waves-effect waves-light" ng-click=logIn()>' +
//                    'Log In' +
//                    '</button></div>' +
//                    ''),
//            title: '',
//            scope: $scope,
//            buttons: [
//                {
//                    text: 'Sign Up',
//                    type: 'button-positive waves-effect waves-light',
//                    onTap: function(e) {
//                        $location.path("/signUp");
//                    }
//                },
//                {
//                    text: 'Cancel',
//                    type: 'button-assertive waves-effect waves-light',
//                    onTap: function(e) {
//
//                    }
//                }
//
//
//            ]
//        });
//    };
});
app.controller('signUpController', function($scope, $ionicPopup, $timeout, $location, $http) {
    $scope.user = {};
    $scope.resetForm = function() {
        $scope.user.name = "";
        $scope.user.email = "";
        $scope.user.contact = "";
        $scope.user.address = "";
        $scope.user.password = "";
        $scope.user.experience = "";
        $scope.user.gender = "";
        $scope.user.speciality = "";
        $scope.user.pincode = "";
        $scope.user.state = "";
        $scope.user.city = "";
    };
    $scope.signUp = function() {
        alert($scope.user.gender + " " + $scope.user.name);
        $.ajax({
            type: "POST",
            url: "http://172.24.49.211:8080/TailoringApplication_/TailorServlet",
            data: {
                action: 'addNewTailor',
                sign_up_name: $scope.user.name,
                sign_up_email: $scope.user.email,
                sign_up_mobileno: $scope.user.contact,
                sign_up_address: $scope.user.address,
                sign_up_password: $scope.user.password,
                sign_up_experince: $scope.user.experience,
                sign_up_gender: $scope.user.gender,
                uploadedImage: "",
                speciality: $scope.user.speciality,
                pincode: $scope.user.pincode,
                statename: $scope.user.state,
                cityname: $scope.user.city
            },
            success: function(data) {
                alert(data);
            },
            error: function() {

            }
        });
    };
    $scope.checkCity = function() {
        if ($scope.user.city === "Other") {
            $("#other").parent().css("display", "block");
            $scope.user.city = "";
        } else {
            $("#other").parent().css("display", "none");
        }
    };
    $scope.get = {};
    $scope.get.getCity = function() {
//        $("#state option:selected").text()
        $.ajax({
            type: "POST",
            url: "http://172.24.49.211:8080/TailoringApplication_/TailorServlet",
            data: {
                action: 'getCityNames',
                stateName: $scope.user.state
            },
            success: function(data) {
                $('#city').html('');
                $scope.cities = JSON.parse(data);
//                $("#state").append("<option>"+$scope.states[0].stateName+"</option>");
                for (var i = 0; i < $scope.cities.length; i++) {
                    $("#city").append("<option>" + $scope.cities[i].cityName + "</option>");
                }
                $("#city").append("<option>Other</option>");
            }
        });
    };
    $scope.get.getState = function() {
//        alert("state");
        $.ajax({
            type: "POST",
            url: "http://172.24.49.211:8080/TailoringApplication_/TailorServlet",
            data: {
                action: 'getStateNames'
            },
            success: function(data) {

                $scope.states = JSON.parse(data);
//                $("#state").append("<option>"+$scope.states[0].stateName+"</option>");
                $('#state').html("<option selected disabled>Choose your state</option>");
                for (var i = 0; i < $scope.states.length; i++) {
                    $("#state").append("<option>" + $scope.states[i].stateName + "</option>");
                }

                console.log($scope.states[0].stateName);
            }
        });
//        $scope.get.getCity();
        console.log($scope.states);
    };
    $scope.setSignUpForm = function() {
//        $('#city').material_select();
        $scope.get.getState();
//        $("ion-content").css("background", "none no-repeat fixed");
//        $("ion-content").css("background-size", "100% 100%");
    };
});
app.controller('logInController', function($scope, $ionicPopup, $timeout, $location, $http) {

    $scope.logIn = function() {
        $location.path("/dashboard");
    };
    $scope.signUp = function() {
        $location.path("/signUp");
    };
});
app.controller('dashboardController', function($scope, $route, $ionicPopup, $timeout, $location, $http, $ionicPlatform, $ionicSideMenuDelegate) {

    $ionicPlatform.onHardwareBackButton(function() {
        if ($ionicSideMenuDelegate.isOpenLeft()) {
            $ionicSideMenuDelegate.toggleLeft();
        }
    });

    $scope.setDashboard = function() {
        $location.path("/dashboard/notification");
        $route.reload();
    };
});
app.controller('newOrderController', function($scope, $ionicPlatform, $ionicSideMenuDelegate, $rootScope, $ionicPopup, $timeout, $location, $http, newOrderAndCatalogService) {

    $ionicPlatform.onHardwareBackButton(function() {
        if ($ionicSideMenuDelegate.isOpenLeft()) {
            $ionicSideMenuDelegate.toggleLeft();
        }
    });

    $scope.customer = {};
    $scope.customer.contact = "";
    $scope.customer.name = "";
    $scope.customer.address = "";
    $scope.customer.state = "";
    $scope.customer.city = "";
    $scope.customer.pincode = "";
    $scope.customer.preference = "";
    $scope.preference = false;
    $scope.order = {};
    $scope.order.category = "Not Selected";
    $scope.order.type = "Not Selected";
    $scope.order.style = "";
    $scope.order.measurement = "";
    $scope.order.quantity = "";
    $scope.order.typeOfMaterial = "";
    $scope.order.additionalRemarks = "";
    $scope.order.additionalItem = "";
    $scope.order.additionalItemRemarks = "";
    $scope.delivery = {};
    $scope.deliveryMode = false;
    $scope.delivery.dateOfOrder = "";
    $scope.delivery.dateOfOrder = "";
    $scope.delivery.deliveryMode = "";
    $scope.payment = {};
    $scope.payment.orderCost = "";
    $scope.payment.additionalItemCost = "";
    $scope.payment.advance = "";
    $scope.payment.total = "";
    $scope.payment.remaining = "";
    $scope.order.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
    $scope.order.types = [{name: "Shirt"}, {name: "Suit"}, {name: "Pant"}];
    $scope.order.measurementProfile = [{name: "Chest", value: "35"}, {name: "Waist", value: "32"}, {name: "Shoulder", value: "37"}, {name: "Arm", value: "20"}, {name: "Neck", value: "8"}];
    $scope.order.measurements = [{measure: "Chest#35"}, {measure: "Waist#32"}, {measure: "Shoulder#37"}, {measure: "Arm#20"}, {measure: "Neck#8"}];
    $scope.order.measurementUnit = "";
    $scope.order.measurementUnitInBoolean = true;
    $scope.showCatalog = function(event) {
        var id = event.target.id;
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        $rootScope.category = $scope.order.category;
        $rootScope.type = $scope.order.type;
//        $rootScope.$broadcast("setCategoryAndTypeValue");
        $location.path("/dashboard/newOrderCatalog");
    };
    $scope.addMeasurementRow = function() {
        this.order.measurementProfile.push({name: '', value: ''});

    };
    $scope.resetMeasurement = function() {
        this.order.measurementProfile = [{name: "Chest", value: "35"}, {name: "Waist", value: "32"}, {name: "Shoulder", value: "37"}, {name: "Arm", value: "20"}, {name: "Neck", value: "8"}];
        this.order.addMeasurementFlag = "";
    };
    $scope.saveMeasurementProfile = function() {
        console.log(this.order.measurementProfile);
        this.order.measurementProfile = [];
        for (var i = 0; i < $($("#measurementDiv").children()).find(".row").length; i++) {
            var measurementName = $($($($($("#measurementDiv").children()).find(".row")[i]).children()[0]).children()[0]).val();
            var measurementValue = $($($($($("#measurementDiv").children()).find(".row")[i]).children()[0]).children()[1]).val();
            this.order.measurementProfile.push({name: measurementName, value: measurementValue});
        }
        console.log(this.order.measurementProfile);
        $location.path("/dashboard/newOrder/order");
    };
    $scope.addRow = function() {
        var measurementObject = {measure: ""};
        this.order.measurements.push(measurementObject);
    };
    $scope.showMeasurementList = function(event) {
        var id = event.target.id;
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        $ionicPopup.show({
            template: $('<label class="item item-divider item-balanced">' +
                    'Measurement Unit' +
                    '</label>' +
                    '<div class="item item-text-wrap">' +
                    '<ion-radio ng-model="order.measurementUnit" ng-value="Inch">Inch</ion-radio>' +
                    '<ion-radio ng-model="order.measurementUnit" ng-value="Centimeter">Centimeter</ion-radio>' +
                    '</div>' +
                    '<div class="list">' +
                    '<label class="item item-divider item-balanced">' +
                    'Measurement Details' +
                    '</label>' +
                    '<div class="item">' +
                    '<div class="row" ng-repeat="measurement in order.measurements">' +
                    '<div class="col col-50">' +
                    '<input type="text" value={{measurement.measure.split("#")[0]}} style="color:black;background-color:transparent;border:1px solid rgb(55, 125, 244);text-align:center">' +
                    '</div>' +
                    '<div class="col col-50">' +
                    '<input type="number" value={{measurement.measure.split("#")[1]}} style="color:black;background-color:transparent;border:1px solid rgb(55, 125, 244);text-align:center">' +
                    '</div>' +
                    '</div>' +
                    '<div class="row">' +
                    '<div class="col" style="text-align:center">' +
                    '<button class="button button-balanced button-small" ng-click="addRow();">Add Row</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    ''),
            title: 'Measurement',
            scope: $scope,
            buttons: [
                {
                    text: 'Done',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                },
                {
                    text: 'Cancel',
                    type: 'button-assertive',
                    onTap: function(e) {

                    }
                }


            ]
        });
    };
    $scope.typeOfMaterials = [{name: "Cotton"}, {name: "Silk"}, {name: "Fabric"}];
    $scope.placeOrder = function() {
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>The Order Placed successfully</p>' +
                    '<p>The Order ID is 123</p>' +
                    '</div>' +
                    ''),
            title: '',
            scope: $scope,
            buttons: [
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                        $scope.customer.contact = "";
                        $scope.customer.name = "";
                        $scope.customer.address = "";
                        $scope.customer.state = "";
                        $scope.customer.city = "";
                        $scope.customer.pincode = "";
                        $scope.customer.preference = "";
                        $scope.order.category = "Not Selected";
                        $scope.order.type = "Not Selected";
                        $scope.order.style = "";
                        $scope.order.measurement = "";
                        $scope.order.measurements = [{measure: "Chest#35"}, {measure: "Waist#32"}, {measure: "Shoulder#37"}, {measure: "Arm#20"}, {measure: "Neck#8"}];
                        $scope.order.quantity = "";
                        $scope.order.typeOfMaterial = "";
                        $scope.order.additionalRemarks = "";
                        $scope.order.additionalItem = "";
                        $scope.order.additionalItemRemarks = "";
                        $scope.delivery.dateOfOrder = "";
                        $scope.delivery.dateOfDelivery = "";
                        $scope.delivery.deliveryMode = "";
                        $scope.payment.orderCost = "";
                        $scope.payment.additionalItemCost = "";
                        $scope.payment.advance = "";
                        $scope.payment.total = "";
                        $scope.payment.remaining = "";
                        $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
                        $("#catalog").parent().parent().parent().find(".selected").removeClass("selected");
                        $("#manual").parent().parent().parent().find(".selected").removeClass("selected");
                        $location.path("dashboard/newOrder/customer");
                    }
                }


            ]
        });
    };
    $scope.resetPersonalInformation = function() {
        alert();
    };
    $scope.reset = function(pageName) {
        if (pageName === "customer") {
            this.customer.contact = "";
            this.customer.name = "";
            this.customer.address = "";
            this.customer.state = "";
            this.customer.city = "";
            this.customer.pincode = "";
            this.customer.preference = "";
        } else if (pageName === "order") {

            this.order.category = "Not Selected";
            this.order.type = "Not Selected";
            this.order.style = "";
            this.order.measurement = "";
            $scope.order.measurements = [{measure: "Chest#35"}, {measure: "Waist#32"}, {measure: "Shoulder#37"}, {measure: "Arm#20"}, {measure: "Neck#8"}];
            this.order.quantity = "";
            this.order.typeOfMaterial = "";
            this.order.additionalRemarks = "";
            this.order.additionalItem = "";
            this.order.additionalItemRemarks = "";
            $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
            $("#catalog").parent().parent().parent().find(".selected").removeClass("selected");
            $("#manual").parent().parent().parent().find(".selected").removeClass("selected");
        } else if (pageName === "payment") {

            this.delivery.dateOfOrder = "";
            this.delivery.dateOfDelivery = "";
            this.delivery.deliveryMode = "";
            this.payment.orderCost = "";
            this.payment.additionalItemCost = "";
            this.payment.advance = "";
            this.payment.total = "";
            this.payment.remaining = "";
        }
    };
    $scope.cancelOrder = function() {

        this.customer.contact = "";
        this.customer.name = "";
        this.customer.address = "";
        this.customer.state = "";
        this.customer.city = "";
        this.customer.pincode = "";
        this.customer.preference = "";
        this.order.category = "Not Selected";
        this.order.type = "Not Selected";
        this.order.style = "";
        this.order.measurement = "";
        $scope.order.measurements = [{measure: "Chest#35"}, {measure: "Waist#32"}, {measure: "Shoulder#37"}, {measure: "Arm#20"}, {measure: "Neck#8"}];
        $scope.order.noOfMeasurementProfile = 1;
        $scope.order.measurementProfile = "";
        this.order.quantity = "";
        this.order.typeOfMaterial = "";
        this.order.additionalRemarks = "";
        this.order.additionalItem = "";
        this.order.additionalItemRemarks = "";
        this.delivery.dateOfOrder = "";
        this.delivery.dateOfDelivery = "";
        this.delivery.deliveryMode = "";
        this.payment.orderCost = "";
        this.payment.additionalItemCost = "";
        this.payment.advance = "";
        this.payment.total = "";
        this.payment.remaining = "";
        $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
        $("#catalog").parent().parent().parent().find(".selected").removeClass("selected");
        $("#manual").parent().parent().parent().find(".selected").removeClass("selected");
        $location.path("dashboard/newOrder/customer");
    };
    $scope.selectCategory = function(event) {

        var id = event.target.id;
        $scope.order.category = id;
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        this.showTypePopup();
    };
    $scope.showTypePopup = function() {

        $scope.typePopup = $ionicPopup.show({
            template: $('<div class="list" style="text-align:center">' +
                    '<div class="item" ng-click="selectType(\'Shirt\')">' +
                    'Shirt' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Suit\')">' +
                    'Suit' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Pant\')">' +
                    'Pant' +
                    '</div>' +
                    '</div>' +
                    ''),
            title: '' + this.order.category,
            scope: $scope,
            buttons: [
            ]
        });
    };
    $scope.selectType = function(type) {
        this.order.type = type;
        this.typePopup.close();
    };
//    $scope.order.dateOfOrder={value: new Date(2013, 9, 22)};


    $scope.loadNewOrder = function() {
//        $location.path("dashboard/newOrder/newOrderTab");
        $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
        $("#catalog").parent().parent().parent().find(".selected").removeClass("selected");
        $("#manual").parent().parent().parent().find(".selected").removeClass("selected");
    };
    $scope.nextContent = function(pageName) {
        if (pageName === "order") {
            $location.path("dashboard/newOrder/order");
        } else if (pageName === "payment") {
            $location.path("dashboard/newOrder/payment");
        } else if (pageName === "customer") {
            $location.path("dashboard/newOrder/customer");
        } else if (pageName === "cart") {
            $location.path("dashboard/newOrder/cart");
        }
    };
    $scope.catalog = {};
    $scope.images = [];
    $scope.catalog.loadImages = function() {
        for (var i = 0; i < 8; i++) {
            $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
        }
    };
    $scope.catalog.confirm = function() {
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Are you sure ?</p>' +
                    '</div>' +
                    ''),
            title: '',
            scope: $scope,
            buttons: [
                {
                    text: 'Yes',
                    type: 'button-balanced',
                    onTap: function(e) {
                        window.history.go(-1);
                    }
                },
                {
                    text: 'No',
                    type: 'button-assertive',
                    onTap: function(e) {
                    }
                }


            ]
        });
    };
    $scope.showImage = function(image) {

        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Image',
            scope: $scope,
            buttons: [
                {
                    text: 'Select',
                    type: 'button-positive',
                    onTap: function(e) {
                        window.history.go(-1);
                    }
                },
                {
                    text: 'Cancel',
                    type: 'button-assertive',
                    onTap: function(e) {
                    }
                }


            ]
        });
    };
    $scope.showUpload = function(event) {
        $("#uploadFile").click();
    };
    $scope.selectMeasurementProfie = function() {
        alert();
        $("#checkIcon").css("visibility", "visible");

    };
    $scope.base64Function = function() {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader)
            return; // no file selected, or no FileReader support

        if (/^image/.test(files[0].type)) { // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function() { // set image data as background of div

                uploadedImage = this.result;
                // alert(uploadedImage);
                //  $("#imagePreview").css("background-image", "url("+this.result+")");
            };
        }
    };
});
app.controller('profileController', function($scope, $ionicPlatform, $ionicSideMenuDelegate, $ionicPopup, $timeout, $location, $http) {

    $ionicPlatform.onHardwareBackButton(function() {
        if ($ionicSideMenuDelegate.isOpenLeft()) {
            $ionicSideMenuDelegate.toggleLeft();
        }
    });

    $scope.updateProfile = function() {
        $location.path("dashboard/profile");
    }

    $scope.showImage = function(image) {

        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Amar Banerjee',
            scope: $scope,
            buttons: [
                {
                    text: 'Edit',
                    type: 'button-balanced',
                    onTap: function(e) {

                    }
                },
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }
            ]
        });
    };
});
//app.controller('newOrderController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http, newOrderAndCatalogService) {
//    $scope.catalog = {};
//
//    $scope.catalog.category = $scope.category;
//    $scope.catalog.type = $scope.type;
//
//
//    $scope.images = [];
//    $scope.catalog.loadImages = function() {
//        for (var i = 0; i < 8; i++) {
//            $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
//        }
////        if ($rootScope.category === "Men") {
////            if ($rootScope.type === "Shirt") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            } else if ($rootScope.type === "Suit") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            } else if ($rootScope.type === "Pant") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            }
////        } else if ($rootScope.category === "Women") {
////            if ($rootScope.type === "Shirt") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            } else if ($rootScope.type === "Suit") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            } else if ($rootScope.type === "Pant") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            }
////        } else if ($rootScope.category === "Children") {
////            if ($rootScope.type === "Shirt") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            } else if ($rootScope.type === "Suit") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            } else if ($rootScope.catalog.type === "Pant") {
////                for (var i = 0; i < 4; i++) {
////                    $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
////                }
////            }
////        }
//    };
//
//    $scope.setCatalogValue = function() {
//
//        $rootScope.category = $scope.catalog.category;
//        $rootScope.type = $scope.catalog.type;
//        this.catalog.loadImages();
//    };
//
//    $scope.$on("setCategoryAndTypeValue", function() {
//        $scope.catalog.category = $rootScope.category;
//        $scope.catalog.type = $rootScope.type;
//    });
//
//    $scope.catalog.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
//    $scope.catalog.types = [{name: "Shirt"}, {name: "Suit"}, {name: "Pant"}];
//
//    $scope.catalog.confirm = function() {
//        $ionicPopup.show({
//            template: $('<div style="text-align:center">' +
//                    '<p>Are you sure ?</p>' +
//                    '</div>' +
//                    ''),
//            title: '',
//            scope: $scope,
//            buttons: [
//                {
//                    text: 'Yes',
//                    type: 'button-balanced',
//                    onTap: function(e) {
//                        window.history.go(-1);
//                    }
//                },
//                {
//                    text: 'No',
//                    type: 'button-assertive',
//                    onTap: function(e) {
//                    }
//                }
//
//
//            ]
//        });
//    };
//
//    $scope.showImage = function(image) {
//
//        $ionicPopup.show({
//            template: $('<div style="text-align:center">' +
//                    '<img src="' + image + '" style="height:50%;width:100%">' +
//                    '</div>' +
//                    ''),
//            title: 'Image',
//            scope: $scope,
//            buttons: [
//                {
//                    text: 'Select',
//                    type: 'button-positive',
//                    onTap: function(e) {
//                        $scope.catalog.confirm();
//                    }
//                },
//                {
//                    text: 'Cancel',
//                    type: 'button-assertive',
//                    onTap: function(e) {
//                    }
//                }
//
//
//            ]
//        });
//
//    };
//
//});

app.controller('orderController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http) {



    $scope.setOrderPage = function() {
        $location.path("dashboard/order/search");
    };
    $scope.disableOtherInputField = function(typeName) {
        if (typeName === "delivery") {
            $("#delivery").prop("disabled", false);
            $("#order").prop("disabled", true);
            $($("#order").parent().children()[0]).removeClass("positive");
            $("#customer").prop("disabled", true);
            $($("#customer").parent().children()[0]).removeClass("positive");
        } else if (typeName === "order") {
            $("#order").prop("disabled", false);
            $("#delivery").prop("disabled", true);
            $($("#delivery").parent().children()[0]).removeClass("positive");
            $("#customer").prop("disabled", true);
            $($("#customer").parent().children()[0]).removeClass("positive");
        } else if (typeName === "customer") {
            $("#customer").prop("disabled", false);
            $("#order").prop("disabled", true);
            $($("#order").parent().children()[0]).removeClass("positive");
            $("#delivery").prop("disabled", true);
            $($("#delivery").parent().children()[0]).removeClass("positive");
        }
    };
    $scope.reset = function() {

        this.deliveryDate = "";
        this.orderID = "";
        this.customerID = "";
        $("#delivery").prop("disabled", false);
        $($("#delivery").parent().children()[0]).addClass("positive");
        $("#order").prop("disabled", false);
        $($("#order").parent().children()[0]).addClass("positive");
        $("#customer").prop("disabled", false);
        $($("#customer").parent().children()[0]).addClass("positive");
    };
    $scope.search = function() {
        $location.path("dashboard/order/details");
    };
    console.log('orderController');
});
app.controller('catalogController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http) {

    $scope.catalog = {};
    $scope.catalog.category = "Not selected";
    $scope.catalog.type = "Not selected";
    $scope.catalog.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
    $scope.catalog.types = [{name: "Shirt"}, {name: "Suit"}, {name: "Pant"}];
    $scope.images = [];
    $scope.catalog.loadImages = function() {
        $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
        $location.path("dashboard/catalog/viewCatalog");
        for (var i = 0; i < 8; i++) {
            $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
        }
    };
    $scope.loadAddCatalog = function() {
        $location.path("dashboard/catalog/addCatalog");
    };
    $scope.selectCategory = function(event) {

        var id = event.target.id;
        $scope.catalog.category = id;
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        this.showTypePopup();
    };
    $scope.showImage = function(image) {

        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Image',
            scope: $scope,
            buttons: [
                {
                    text: 'Place Order',
                    type: 'button-balanced',
                    onTap: function(e) {

                    }
                },
                {
                    text: 'Cancel',
                    type: 'button-assertive',
                    onTap: function(e) {
                    }
                }
            ]
        });
    };
    $scope.showTypePopup = function() {

        $scope.typePopup = $ionicPopup.show({
            template: $('<div class="list" style="text-align:center">' +
                    '<div class="item" ng-click="selectType(\'Shirt\')">' +
                    'Shirt' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Suit\')">' +
                    'Suit' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Pant\')">' +
                    'Pant' +
                    '</div>' +
                    '</div>' +
                    ''),
            title: '' + this.catalog.category,
            scope: $scope,
            buttons: [
            ]
        });
    };
    $scope.selectType = function(type) {
        this.catalog.type = type;
        this.typePopup.close();
    };
    console.log('catalogController');
});
app.controller('teamManagementController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http) {

    $scope.employee = {};
    $scope.employee.name = "";
    $scope.employee.gender = "";
    $scope.employee.contact = "";
    $scope.employee.address = "";
    $scope.employee.email = "";
    $scope.employee.speciality = "";
    $scope.employee.designation = "";
    $scope.employee.salary = "";
    $scope.editEmployee = {};
    $scope.editEmployee.id = "880053";
    $scope.editEmployee.name = "Gaurav Sanyal";
    $scope.editEmployee.gender = "Male";
    $scope.editEmployee.contact = "9874561230";
    $scope.editEmployee.address = "Kolkata, West Bengal";
    $scope.editEmployee.email = "gaurav@tcs.com";
    $scope.editEmployee.speciality = "Men Shirt";
    $scope.editEmployee.designation = "Tailor";
    $scope.editEmployee.salary = 2000;
    $scope.search = {};
    $scope.searchResult = {};
    $scope.search.searchParameter = "";
    $scope.search.searchValue = "";
    $scope.searchResult.searchParameter = "";
    $scope.searchResult.searchValue = "";
    $scope.searchOptions = [{parameter: "Employee ID"}, {parameter: "Employee Name"}];

    $scope.disableOtherInputField = function(typeName) {
        if (typeName === "id") {
            $("#employeeName").prop("disabled", true);
            $($("#employeeName").parent().children()[0]).removeClass("positive");
        } else if (typeName === "name") {
            $("#employeeId").prop("disabled", true);
            $($("#employeeId").parent().children()[0]).removeClass("positive");
        }

    };
    $scope.resetSearchEmployee = function() {
        this.search.searchParameter = "";
        this.search.searchValue = "";
        $($("#employeeName").parent().children()[0]).addClass("positive");
        $("#employeeName").prop("disabled", false);
        $($("#employeeId").parent().children()[0]).addClass("positive");
        $("#employeeId").prop("disabled", false);
    }
    ;
    $scope.searchEmployee = function() {
        $location.path("dashboard/teamManagement/searchResults");
    };
    $scope.showEmployeeDetails = function() {
        $location.path("dashboard/teamManagement/employeeDetails");
    };
    $scope.backToSearchResults = function() {
        window.history.go(-1);
    };
    $scope.loadTeamManagement = function() {
        $location.path("dashboard/teamManagement/viewEmployee");
    };
    $scope.loadAddEmployee = function() {
        $location.path("dashboard/teamManagement/addEmployee");
    };
    $scope.addEmployeeData = function() {
        this.employee.name = "";
        this.employee.gender = "";
        this.employee.contact = "";
        this.employee.address = "";
        this.employee.email = "";
        this.employee.speciality = "";
        this.employee.designation = "";
        this.employee.salary = "";
        var addedPopup = $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Employee data added successfully</p>' +
                    '</div>' +
                    ''),
            title: 'Success',
            scope: $scope,
            buttons: [
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }
            ]
        });
    };
    $scope.editDetails = function() {
        $location.path("/dashboard/teamManagement/editEmployeeDetails");
    };
    $scope.editEmployeeData = function() {
        var updatedPopup = $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Employee data updated successfully</p>' +
                    '</div>' +
                    ''),
            title: 'Success',
            scope: $scope,
            buttons: [
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                        $location.path("/dashboard/teamManagement/employeeDetails");
                    }
                }
            ]
        });
    };
    $scope.deleteEmployee = function() {
        var deletedPopup = $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Are you sure you want to delete this employee data ?</p>' +
                    '</div>' +
                    ''),
            title: 'Confirm',
            scope: $scope,
            buttons: [
                {
                    text: 'Yes',
                    type: 'button-balanced',
                    onTap: function(e) {
                        $location.path("/dashboard/teamManagement/searchResults");
                    }
                },
                {
                    text: 'No',
                    type: 'button-assertive',
                    onTap: function(e) {

                    }
                }
            ]
        });
    };
    $scope.resetEmployeeData = function() {
        this.employee.name = "";
        this.employee.gender = "";
        this.employee.contact = "";
        this.employee.address = "";
        this.employee.email = "";
        this.employee.speciality = "";
        this.employee.designation = "";
        this.employee.salary = "";
    };
    console.log('teamManagementController');
});
app.controller('settingsController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http) {

    $scope.measurement = {};
    $scope.delivery = {};
    $scope.measurement.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
    $scope.measurement.types = [{name: "Shirt"}, {name: "Suit"}, {name: "T-Shirt"}];
    $scope.measurement.category = "Not selected";
    $scope.measurement.type = "Not selected";
    $scope.measurement.addParameterName = "";
    $scope.measurement.measurementsParameter = [{name: "Chest"}, {name: "Body Length"}, {name: "Shoulder"}, {name: "Arm"}, {name: "Neck"}, {name: "Wrist"}];

    $scope.delivery.expressDeliveryDayNo = 7;
    $scope.delivery.standardDeliveryDayNo = 15;

    $scope.setSettings = function() {
        $location.path("dashboard/settings/measurement");
    };

    $scope.addMeasurement = function() {
        this.measurement.addParameterName = "";
        $scope.addPopup = $ionicPopup.show({
            template: $('<label class="item item-input">' +
                    '<span class="input-label positive">Measurement Name</span>' +
                    '<input ng-model="measurement.addParameterName" type="text">' +
                    '</label>' +
                    ''),
            title: 'Add Measurement Parameter',
            scope: $scope,
            buttons: [
                {
                    text: 'Add',
                    type: 'button-positive',
                    onTap: function(e) {
                        $scope.measurement.measurementsParameter.push({name: $scope.measurement.addParameterName});
                        $location.path("/dashboard/settings/measurement");
                    }
                },
                {
                    text: 'Cancel',
                    type: 'button-assertive',
                    onTap: function(e) {

                    }
                }
            ]
        });
    };

    $scope.selectCategory = function(event) {

        var id = event.target.id;
        $scope.measurement.category = $($("#" + id).parent().children()[1]).html();
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        this.showTypePopup();
    };
    $scope.showTypePopup = function() {

        $scope.typePopup = $ionicPopup.show({
            template: $('<div class="list" style="text-align:center">' +
                    '<div class="item" ng-click="selectType(\'Shirt\')">' +
                    'Shirt' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Suit\')">' +
                    'Suit' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Kurta\')">' +
                    'Pant' +
                    '</div>' +
                    '</div>' +
                    ''),
            title: '' + this.measurement.category,
            scope: $scope,
            buttons: [
            ]
        });
    };
    $scope.selectType = function(type) {
        this.measurement.type = type;
        this.typePopup.close();
        var path = $location.path();
        if (path === "/dashboard/settings/delivery") {
            $("#deliveryDiv").css("display", "block");
        } else if (path === "/dashboard/settings/measurement") {
//            alert(path)
            $("#measurementDiv").css("display", "block");
        } else {

        }
    };
    $scope.showDeliDiv = function() {
        $("#measurementDiv").css("display", "block");
    };
    $scope.editMeasurementParameter = function() {
        $("#saveMeasurementButton").css("display", "inline-block");
        $("#editMeasurementButton").css("display", "none");
        $("#addMeasurementParameterButton").css("display", "inline-block");
        for (var i = 0; i < $(".measurementInputBox").length; i++) {
            $($(".measurementInputBox")[i]).css("background-color", "transparent");
            $($(".measurementInputBox")[i]).prop("disabled", false);
        }
    };
    $scope.resetMeasurementParameter = function() {
        $("#saveMeasurementButton").css("display", "none");
        $("#editMeasurementButton").css("display", "inline-block");
        $("#addMeasurementParameterButton").css("display", "none");
        for (var i = 0; i < $(".measurementInputBox").length; i++) {
            $($(".measurementInputBox")[i]).prop("disabled", true);
        }
    };
    $scope.saveMeasurementParameter = function() {
        $("#saveMeasurementButton").css("display", "none");
        $("#editMeasurementButton").css("display", "inline-block");
        $("#addMeasurementParameterButton").css("display", "none");
        for (var i = 0; i < $(".measurementInputBox").length; i++) {
            $($(".measurementInputBox")[i]).prop("disabled", true);
        }
        var updatedPopup = $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Measurement data updated successfully</p>' +
                    '</div>' +
                    ''),
            title: 'Success',
            scope: $scope,
            buttons: [
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }
            ]
        });
    };

    $scope.editDeliveryParameter = function() {
        $("#saveDeliveryButton").css("display", "inline-block");
        $("#editDeliveryButton").css("display", "none");
        $($(".deliveryInputBox").parent().find(".deliveryInputBox")).prop("disabled", false);
    };
    $scope.resetDeliveryParameter = function() {
        $("#editDeliveryButton").css("display", "inline-block");
        $("#saveDeliveryButton").css("display", "none");
        $($(".deliveryInputBox").parent().find(".deliveryInputBox")).prop("disabled", true);
    };
    $scope.saveDeliveryParameter = function() {
        $("#editDeliveryButton").css("display", "inline-block");
        $("#saveDeliveryButton").css("display", "none");
        $($(".deliveryInputBox").parent().find(".deliveryInputBox")).prop("disabled", true);
        var updatedPopup = $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Measurement data updated successfully</p>' +
                    '</div>' +
                    ''),
            title: 'Success',
            scope: $scope,
            buttons: [
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }
            ]
        });
    };
    console.log('settingsController');
});
app.controller('expenseController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http) {

    $scope.expenses = [];
    $scope.expense = {};
    $scope.years = [{number: 2014}, {number: 2015}];
    $scope.types = [{name: "Salary"}, {name: "Machine"}, {name: "Materials"}, {name: "Others"}];
    $scope.loadExpense = function() {
        $location.path("/dashboard/expense/view");
    };
    $scope.loadAddExpense = function() {
        $location.path('dashboard/expense/addExpense');
    };
    $scope.addExpenseData = function() {
        this.expenses.push(this.expense);
        this.expense.type = "";
        this.expense.cost = "";
        this.expense.date = "";
        this.expense.description = "";
        var addedPopup = $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<p>Expenses data added successfully</p>' +
                    '</div>' +
                    ''),
            title: '',
            scope: $scope,
            buttons: [
                {
                    text: 'Ok',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }
            ]
        });
        console.log($scope.expenses);
    };
    $scope.resetExpenseData = function() {

    };
    $scope.showExpenseDetails = function() {
        $location.path("dashboard/expense/expenseDetails");
    };
    $scope.showExpenseDescription = function() {
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<div class="card">' +
                    '<div class="item item-balanced">' +
                    '<div class="item item-divider">' +
                    'Date : 12/01/2015' +
                    '</div>' +
                    '<div class="item item-text-wrap">' +
                    '2 Sewing Machines ' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    ''),
            title: 'Date & Description details',
            scope: $scope,
            buttons: [
                {
                    text: 'Close',
                    type: 'button-balanced',
                    onTap: function(e) {
                    }
                }
            ]
        });
    };
    console.log($scope.expenses.length);
});
app.controller('chartController', function($scope) {

    $scope.loadChart = function() {
        $('#barChart').highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: 'Fruit Consumption'
            },
            xAxis: {
                categories: ['Apples', 'Bananas', 'Oranges']
            },
            yAxis: {
                title: {
                    text: 'Fruit eaten'
                }
            },
            credits: { 
                enabled: false
            },
            series: [{
                    name: 'Jane',
                    data: [1, 0, 4]
                }, {
                    name: 'John',
                    data: [5, 7, 3]
                }]
        });
    };

    console.log('chartController');
});
app.controller('notificationController', function($scope, $rootScope, $state, $ionicPopup, $timeout, $location, $http) {
    $scope.noOfNotification = 2;
});
app.controller('homeCtrl', function($scope) {
    console.log('homeCtrl');
});
app.controller('customerController', function($scope) {
    console.log('customerController');
});
app.controller('customerMyDesignController', function($scope) {




    console.log('customerMyDesignController');
});
app.controller('customerProfileController', function($scope, $ionicPopup, $location) {
    $scope.showProfileImage = function(image) {
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Mrinmoy Chakraborty',
            scope: $scope,
            buttons: [
                {
                    text: 'Edit',
                    type: 'button-balanced',
                    onTap: function(e) {

                    }
                },
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function(e) {

                    }
                }
            ]
        });
    };
    $scope.loadMyDesign = function() {
        $location.path("/myDesignOfCustomer");
    };
    $scope.showCatalogImage = function(image, cost) {
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Image',
            scope: $scope,
            buttons: [
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }


            ]
        });
    };

    $scope.goBack = function() {
        window.history.go(-1);
    };
    console.log('customerProfileController');
});
app.controller('customerMyTailorsController', function($scope) {
    console.log('customerMyTailorsController');
});
app.controller('createDesignController', function($scope, $ionicSideMenuDelegate) {
    $scope.customerCanvasElement = {};
    $scope.customerCanvasElement.lineWidth = 1;
    $scope.goBack = function() {
        window.history.go(-1);
    };

    $scope.saveDesign = function() {
        $ionicSideMenuDelegate.toggleRight();
    };

    $scope.closeSideBar = function() {
        $ionicSideMenuDelegate.toggleRight();
    };

    $scope.loadCanvas = function() {
        startCanvasStudio();
        initG();
        initMain();
    };


    console.log('createDesignController');
});
app.controller('myDesignOfCustomerController', function($scope, $ionicPopup) {

    $scope.images = [];

    $scope.loadImages = function() {
        for (var i = 0; i < 8; i++) {
            $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg"});
        }
    };

    $scope.showCatalogImage = function(image) {
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Image',
            scope: $scope,
            buttons: [
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }


            ]
        });
    };



    $scope.goBack = function() {
        window.history.go(-1);
    };
    console.log('myDesignOfCustomerController');
});
app.controller('trackOrderController', function($scope) {
    console.log('trackOrderController');
});

app.controller('searchTailorController', function($scope, $route, $rootScope, $location, $ionicPopup) {

    $scope.catalog = {};
    $scope.catalog.category = "Not selected";
    $scope.catalog.type = "Not selected";
    $scope.catalog.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
    $scope.catalog.types = [{name: "Shirt"}, {name: "Suit"}, {name: "Pant"}];
    $scope.images = [];
    $scope.catalog.loadImages = function() {
        $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
//        $location.path("dashboard/catalog/viewCatalog");
        for (var i = 0; i < 8; i++) {
            $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg", cost: "700"});
        }
    };


    $scope.disableOtherInputField = function(typeName) {
        if (typeName === "Name") {
            $("#tailorName").prop("disabled", false);
            $("#tailorContact").prop("disabled", true);
            $($("#tailorContact").parent().children()[0]).removeClass("positive");
            $($("#tailorName").parent().children()[0]).removeClass("positive");
            $($("#tailorName").parent().children()[0]).addClass("positive");
        } else if (typeName === "Contact") {
            $("#tailorContact").prop("disabled", false);
            $("#tailorName").prop("disabled", true);
            $($("#tailorName").parent().children()[0]).removeClass("positive");
            $($("#tailorContact").parent().children()[0]).removeClass("positive");
            $($("#tailorContact").parent().children()[0]).addClass("positive");
        }
    };

    $scope.searchTailor = function() {
        $location.path("/searchTailor/searchTailorResult");
    };

    $scope.resetSearch = function() {
        $route.reload();
    };

    $scope.showProfileImage = function(image) {

        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    ''),
            title: 'Amar Banerjee',
            scope: $scope,
            buttons: [
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function(e) {

                    }
                }
            ]
        });
    };
    $scope.showCatalogImage = function(image, cost) {
        console.log($rootScope.category);
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    '<div class="item item-positive item-divider" style="text-align: center">' +
                    cost + ' INR' +
                    '</div>' +
                    ''),
            title: 'Image',
            scope: $scope,
            buttons: [
                {
                    text: 'Place Order',
                    type: 'button-balanced',
                    onTap: function(e) {

                    }
                },
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }


            ]
        });
    };
    $scope.goBack = function() {
        window.history.go(-1);
    };


    console.log('searchTailorController');
});
app.controller('newOrderFromCustomerController', function($scope, $ionicPopup, $rootScope, $location) {

    $scope.customer = {};
    $scope.customer.contact = "";
    $scope.customer.name = "";
    $scope.customer.address = "";
    $scope.customer.state = "";
    $scope.customer.city = "";
    $scope.customer.pincode = "";
    $scope.customer.preference = "";
    $scope.preference = false;
    $scope.order = {};
    $scope.order.category = "Not Selected";
    $scope.order.type = "Not Selected";
    $scope.order.style = "";
    $scope.order.measurement = "";
    $scope.order.quantity = "";
    $scope.order.typeOfMaterial = "";
    $scope.order.additionalRemarks = "";
    $scope.order.additionalItem = "";
    $scope.order.additionalItemRemarks = "";
    $scope.delivery = {};
    $scope.deliveryMode = false;
    $scope.delivery.dateOfOrder = "";
    $scope.delivery.dateOfOrder = "";
    $scope.delivery.deliveryMode = "";
    $scope.payment = {};
    $scope.payment.orderCost = "";
    $scope.payment.additionalItemCost = "";
    $scope.payment.advance = "";
    $scope.payment.total = "";
    $scope.payment.remaining = "";
    $scope.order.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
    $scope.order.types = [{name: "Shirt"}, {name: "Suit"}, {name: "Pant"}];
    $scope.order.measurements = [{measure: "Chest#35"}, {measure: "Waist#32"}, {measure: "Shoulder#37"}, {measure: "Arm#20"}, {measure: "Neck#8"}];

    $scope.catalog = {};
    $scope.catalog.category = "Not selected";
    $scope.catalog.type = "Not selected";
    $scope.catalog.categories = [{name: "Men"}, {name: "Women"}, {name: "Children"}];
    $scope.catalog.types = [{name: "Shirt"}, {name: "Suit"}, {name: "Pant"}];
    $scope.images = [];
    $scope.catalog.loadImages = function() {
        $("#Men").parent().parent().parent().find(".selected").removeClass("selected");
//        $location.path("dashboard/catalog/viewCatalog");
        for (var i = 0; i < 8; i++) {
            $scope.images.push({id: i, src: "view/images/menshirt" + (i + 1) + ".jpg", cost: "700"});
        }
    };

    $scope.showCatalog = function(event) {
        var id = event.target.id;
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        $rootScope.category = $scope.order.category;
        $rootScope.type = $scope.order.type;
//        $rootScope.$broadcast("setCategoryAndTypeValue");
        $location.path("/searchTailor/tailorCatalogForCustomer");
    };

    $scope.selectCategory = function(event) {

        var id = event.target.id;
        $scope.order.category = id;
        $($("#" + id).parent().parent().parent().find(".selected")).removeClass("selected");
        $("#" + id).addClass("selected");
        this.showTypePopup();
    };
    $scope.showTypePopup = function() {

        $scope.typePopup = $ionicPopup.show({
            template: $('<div class="list" style="text-align:center">' +
                    '<div class="item" ng-click="selectType(\'Shirt\')">' +
                    'Shirt' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Suit\')">' +
                    'Suit' +
                    '</div>' +
                    '<div class="item" ng-click="selectType(\'Pant\')">' +
                    'Pant' +
                    '</div>' +
                    '</div>' +
                    ''),
            title: '' + this.order.category,
            scope: $scope,
            buttons: [
            ]
        });
    };
    $scope.selectType = function(type) {
        this.order.type = type;
        this.typePopup.close();
    };

    $scope.showCatalogImage = function(image, cost) {
        console.log($rootScope.category);
        $ionicPopup.show({
            template: $('<div style="text-align:center">' +
                    '<img src="' + image + '" style="height:50%;width:100%">' +
                    '</div>' +
                    '<div class="item item-positive item-divider" style="text-align: center">' +
                    cost + ' INR' +
                    '</div>' +
                    ''),
            title: 'Image',
            scope: $scope,
            buttons: [
                {
                    text: 'Select',
                    type: 'button-balanced',
                    onTap: function(e) {

                    }
                },
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function(e) {
                    }
                }


            ]
        });
    };


    console.log('newOrderFromCustomerController');
});
app.config(['$ionicConfigProvider', function($ionicConfigProvider) {

//$ionicConfigProvider.tabs.style('standard');
        $ionicConfigProvider.tabs.position('bottom'); //other values: top

    }]);
