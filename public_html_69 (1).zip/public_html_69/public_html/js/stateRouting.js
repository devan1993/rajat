var app = angular.module('tailringApplication', ['ionic', 'ngRoute', 'ui.router'])
        .run(function($rootScope) {
    $rootScope.category = "";
    $rootScope.type = "";
});

app.config(function($routeProvider, $stateProvider, $urlRouterProvider) {

    $stateProvider
            .state('home', {
        url: "/",
        templateUrl: "view/tabs.html",
        controller: "signUpController"
    })
            .state('tabs', {
        url: "/tabs",
        templateUrl: "view/tabs.html",
        controller: "mainCtrl"
    })
            .state('tabs.home', {
        url: "/home",
        templateUrl: "view/home.html",
        views: {
            'home-tab': {
                templateUrl: "view/home.html",
                controller: 'homeCtrl'
            }
        }
    })
            .state('tabs.tailor', {
        url: "/tailor",
        templateUrl: "view/tailor.html",
        views: {
            'tailor-tab': {
                templateUrl: "view/tailor.html",
                controller: 'logInController'
            }
        }
    })
            .state('tabs.customer', {
        url: "/customer",
        templateUrl: "view/customer.html",
        views: {
            'customer-tab': {
                templateUrl: "view/customer.html",
                controller: 'customerController'
            }
        }
    })
            .state('signUp', {
        url: "/signUp",
        templateUrl: "view/signUp.html",
        controller: "signUpController"
    })
            .state('trackOrder', {
        url: "/trackOrder",
        templateUrl: "view/trackOrder.html",
        controller: "trackOrderController"
    })
            .state('customerProfile', {
        url: "/customerProfile",
        templateUrl: "view/customerProfile.html",
        controller: "customerProfileController"
    })
            .state('editCustomerProfile', {
        url: "/editCustomerProfile",
        templateUrl: "view/editCustomerProfile.html",
        controller: "customerProfileController"
    })
            .state('customerMyTailors', {
        url: "/customerMyTailors",
        templateUrl: "view/customerMyTailors.html",
        controller: "customerMyTailorsController"
    })
            .state('customerMyDesign', {
        url: "/customerMyDesign",
        templateUrl: "view/customerMyDesign.html",
        controller: "customerMyDesignController"
    })
            .state('searchTailor', {
        url: "/searchTailor",
        templateUrl: "view/searchTailor.html",
        controller: "searchTailorController"
    })
            .state('searchTailor.searchQuery', {
        url: "/searchQuery",
        views: {
            'searchTailor': {
                templateUrl: "view/searchQuery.html",
                controller: 'searchTailorController'
            }
        }
    })
            .state('searchTailor.searchTailorResult', {
        url: "/searchTailorResult",
        views: {
            'searchTailor': {
                templateUrl: "view/searchTailorResult.html",
                controller: 'searchTailorController'
            }
        }
    })
            .state('searchTailor.tailorProfileDetails', {
        url: "/tailorProfileDetails",
        views: {
            'searchTailor': {
                templateUrl: "view/tailorProfileForCustomer.html",
                controller: 'searchTailorController'
            }
        }
    })
            .state('searchTailor.tailorCatalogForCustomer', {
        url: "/tailorCatalogForCustomer",
        views: {
            'searchTailor': {
                templateUrl: "view/tailorCatalogForCustomer.html",
                controller: 'searchTailorController'
            }
        }
    })
            .state('newOrderRequestOfCustomer', {
        url: "/newOrderRequestOfCustomer",
        templateUrl: "view/newOrderRequestOfCustomer.html",
        controller: "newOrderFromCustomerController"
    })
            .state('newOrderRequestOfCustomer.personal', {
        url: "/personal",
        templateUrl: "view/customerPersonalDetails.html",
        views: {
            'personal-tab': {
                templateUrl: "view/customerPersonalDetails.html",
                controller: 'newOrderFromCustomerController'
            }
        }
    })
            .state('newOrderRequestOfCustomer.order', {
        url: "/order",
        templateUrl: "view/customerOrderDetails.html",
        views: {
            'order-tab': {
                templateUrl: "view/customerOrderDetails.html",
                controller: 'newOrderFromCustomerController'
            }
        }
    })
            .state('newOrderRequestOfCustomer.catalog', {
        url: "/catalog",
        templateUrl: "view/catalogForCustomerNewOrder.html",
        views: {
            'order-tab': {
                templateUrl: "view/catalogForCustomerNewOrder.html",
                controller: 'newOrderFromCustomerController'
            }
        }
    })
            .state('orderDetailsOfOrderPlacedByCustomer', {
        url: "/orderDetailsOfOrderPlacedByCustomer",
        templateUrl: "view/orderDetailsOfOrderPlacedByCustomer.html",
        controller: 'newOrderFromCustomerController'
    })
            .state('cart', {
        url: "/cart",
        templateUrl: "view/cartForCustomer.html",
        controller: 'newOrderFromCustomerController'
    })
            .state('createDesignByCustomer', {
        url: "/createDesignByCustomer",
        templateUrl: "view/canvasForCustomer.html",
        controller: "createDesignController"
    })
            .state('myDesignOfCustomer', {
        url: "/myDesignOfCustomer",
        templateUrl: "view/customerMyDesign.html",
        controller: "myDesignOfCustomerController"
    })
            .state('dashboard', {
        url: "/dashboard",
        templateUrl: "view/dashboard.html",
        controller: "dashboardController"
    })
            .state('dashboard.notification', {
        url: "/notification",
        views: {
            'menuContent': {
                templateUrl: "view/notification.html",
                controller: 'notificationController'
            }
        }
    })
            .state('dashboard.newOrder', {
        url: "/newOrder",
        views: {
            'menuContent': {
                templateUrl: "view/newOrderTab.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrder.customer', {
        url: "/customer",
        templateUrl: "view/newOrderCustomerContent.html",
        views: {
            'customer-tab': {
                templateUrl: "view/newOrderCustomerContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrder.order', {
        url: "/order",
        templateUrl: "view/newOrderOrderDetailsContent.html",
        views: {
            'order-tab': {
                templateUrl: "view/newOrderOrderDetailsContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrderPayment', {
        url: "/payment",
        templateUrl: "view/newOrderPaymentDetailsContent.html",
        views: {
            'menuContent': {
                templateUrl: "view/newOrderPaymentDetailsContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrderCart', {
        url: "/cart",
        views: {
            'menuContent': {
                templateUrl: "view/newOrderCart.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.orderDetailsFromCart', {
        url: "/orderDetailsFromCart",
        views: {
            'menuContent': {
                templateUrl: "view/newOrderOrderDetailsFromCart.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.profile', {
        url: "/profile",
        views: {
            'menuContent': {
                templateUrl: "view/profile.html",
                controller: 'profileController'
            }
        }
    })
            .state('dashboard.editProfile', {
        url: "/editProfile",
        views: {
            'menuContent': {
                templateUrl: "view/editProfile.html",
                controller: 'profileController'
            }
        }
    })
            .state('dashboard.newOrder.newOrderCustomerContent', {
        url: "/customer",
        views: {
            'newOrderContent': {
                templateUrl: "view/newOrderCustomerContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrderCatalog', {
        url: "/newOrderCatalog",
        views: {
            'menuContent': {
                templateUrl: "view/newOrderCatalogDetails.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrder.newOrderOrderDetailsContent', {
        url: "/order",
        views: {
            'newOrderContent': {
                templateUrl: "view/newOrderOrderDetailsContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrder.newOrderPaymentDetailsContent', {
        url: "/payment",
        views: {
            'newOrderContent': {
                templateUrl: "view/newOrderPaymentDetailsContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.newOrder.newOrderCart', {
        url: "/cart",
        views: {
            'newOrderContent': {
                templateUrl: "view/newOrderCart.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.order', {
        url: "/order",
        views: {
            'menuContent': {
                templateUrl: "view/order.html",
                controller: 'orderController'
            }
        }
    })
            .state('dashboard.measurementContent', {
        url: "/measurement",
        templateUrl: "view/measurementContent.html",
        views: {
            'menuContent': {
                templateUrl: "view/measurementContent.html",
                controller: 'newOrderController'
            }
        }
    })
            .state('dashboard.order.orderDescriptionDetails', {
        url: "/orderDescriptionDetails",
        views: {
            'order': {
                templateUrl: "view/orderDescriptionDetails.html",
                controller: 'orderController'
            }
        }
    })
            .state('dashboard.order.search', {
        url: "/search",
        views: {
            'order': {
                templateUrl: "view/orderSearch.html",
                controller: 'orderController'
            }
        }
    })
            .state('dashboard.order.details', {
        url: "/details",
        views: {
            'order': {
                templateUrl: "view/orderDetails.html",
                controller: 'orderController'
            }
        }
    })
            .state('dashboard.chart', {
        url: "/chart",
        views: {
            'menuContent': {
                templateUrl: "view/chartPage.html",
                controller: 'chartController'
            }
        }
    })
            .state('dashboard.expense', {
        url: "/expense",
        views: {
            'menuContent': {
                templateUrl: "view/expense.html",
                controller: 'expenseController'
            }
        }
    })
            .state('dashboard.expense.view', {
        url: "/view",
        views: {
            'expense': {
                templateUrl: "view/expenseView.html",
                controller: 'expenseController'
            }
        }
    })
            .state('dashboard.expense.add', {
        url: "/addExpense",
        views: {
            'expense': {
                templateUrl: "view/expenseAdd.html",
                controller: 'expenseController'
            }
        }
    })
            .state('dashboard.expense.details', {
        url: "/expenseDetails",
        views: {
            'expense': {
                templateUrl: "view/expenseDetails.html",
                controller: 'expenseController'
            }
        }
    })
            .state('dashboard.catalog', {
        url: "/catalog",
        views: {
            'menuContent': {
                templateUrl: "view/catalog.html",
                controller: 'catalogController'
            }
        }
    })
            .state('dashboard.catalog.view', {
        url: "/viewCatalog",
        views: {
            'catalog': {
                templateUrl: "view/catalogView.html",
                controller: 'catalogController'
            }
        }
    })
            .state('dashboard.catalog.add', {
        url: "/addCatalog",
        views: {
            'catalog': {
                templateUrl: "view/catalogAdd.html",
                controller: 'catalogController'
            }
        }
    })
            .state('dashboard.teamManagement', {
        url: "/teamManagement",
        views: {
            'menuContent': {
                templateUrl: "view/teamManagement.html",
                controller: 'teamManagementController'
            }
        }
    })
            .state('dashboard.teamManagement.view', {
        url: "/viewEmployee",
        views: {
            'team': {
                templateUrl: "view/employeeView.html",
                controller: 'teamManagementController'
            }
        }
    })
            .state('dashboard.teamManagement.add', {
        url: "/addEmployee",
        views: {
            'team': {
                templateUrl: "view/employeeAdd.html",
                controller: 'teamManagementController'
            }
        }
    })
            .state('dashboard.teamManagement.searchResults', {
        url: "/searchResults",
        views: {
            'team': {
                templateUrl: "view/employeesearchResults.html",
                controller: 'teamManagementController'
            }
        }
    })
            .state('dashboard.teamManagement.employeeDetails', {
        url: "/employeeDetails",
        views: {
            'team': {
                templateUrl: "view/employeeDetails.html",
                controller: 'teamManagementController'
            }
        }
    })
            .state('dashboard.teamManagement.editEmployeeDetails', {
        url: "/editEmployeeDetails",
        views: {
            'team': {
                templateUrl: "view/editEmployeeDetails.html",
                controller: 'teamManagementController'
            }
        }
    })
            .state('dashboard.settings', {
        url: "/settings",
        views: {
            'menuContent': {
                templateUrl: "view/settings.html",
                controller: 'settingsController'
            }
        }
    })
            .state('dashboard.settings.measurement', {
        url: "/measurement",
        views: {
            'measurement-tab': {
                templateUrl: "view/measurementSettings.html",
                controller: 'settingsController'
            }
        }
    })
            .state('dashboard.settings.delivery', {
        url: "/delivery",
        views: {
            'delivery-tab': {
                templateUrl: "view/deliverySettings.html",
                controller: 'settingsController'
            }
        }
    })

            ;
    $urlRouterProvider.otherwise("/tabs/home");

//    $routeProvider
//            .when("/", {
//        templateUrl: "view/home.html",
//        controller: "mainCtrl"
//    })
//            .when("/signUp", {
//        templateUrl: "view/signUp.html",
//        controller: "signUpController"
//    })
//            .when("/logIn", {
//        templateUrl: "view/logIn.html",
//        controller: "logController"
//    });

});



//app.config(function($stateProvider, $urlRouterProvider) {
//    $stateProvider
//            .state('home', {
//        url: "/home",
//        templateUrl: "/home"
//    })
//            .state('signup', {
//        url: "/signup",
//        templateUrl: "view/signUp.html"
//    });
//    $urlRouterProvider.otherwise("/home");
//});