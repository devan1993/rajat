//Working on 6*6 grid

function changeFunc() {
    var r = document.getElementById('selectBox').value;
    r = parseInt(r);
    if (r === 0) {
        innerHTML0();
    } else if (r === 1) {
        innerHTML1();
    } else {
        innerHTML2();
    }
}
function innerHTML0() {
    document.getElementById('cCanvas').innerHTML = "<canvas id='mCanvas' width='900' height='450'></canvas>";
    initMain();
}

function innerHTML1() {
    document.getElementById('cCanvas').innerHTML = "<canvas id='mCanvas' width='120' height='120'></canvas>";
    initMain();
}
function innerHTML2() {
    document.getElementById('cCanvas').innerHTML = "<canvas id='mCanvas' width='240' height='240'></canvas>";
    initMain();
}

var canvasG;
var groupG;
var g = 10;
function assignGrid() {
    g = parseInt(document.getElementById("gSize").value);
}
var routFlag = false;
function router() {
    if (routFlag === false) {
        gridMain();
        routFlag = true;
    } else {
        removeGrid();
        routFlag = false;
    }
}
function initG() {
    canvasG = new fabric.Canvas('MyCanvas');
    canvasG.on('mouse:down', myDown6, false);
    grid6();
    createG();
}
function grid6() {
    groupG = new fabric.Group();
    var count = 0;
    for (var i = -0.8; i < 6 * g; i += g) {
        var line1 = new fabric.Line([i, 0, i, 6 * g], {stroke: "black", lineWidth: 1, left: i, top: 0});
        var line2 = new fabric.Line([0, i, 6 * g, i], {stroke: "black", lineWidth: 1, left: 0, top: i});
        groupG.add(line1, line2);
        count++;
        if (count === 7) {
            break;
        }
    }
    canvasG.add(groupG);
}


var a = new Array(6);
var rect = new Array(6);

function createG() {
    for (var i = 0; i < 6; i++) {
        a[i] = new Array(6);
    }
    for (var i = 0; i < 6; i++) {
        for (var j = 0; j < 6; j++) {
            a[i][j] = false;
        }
    }
    for (var i = 0; i < 6; i++) {
        rect[i] = new Array(6);
    }
}


function myDown6(o) {
    var pointer = canvasG.getPointer(o.e);
    var x = pointer.x;
    var y = pointer.y;
    if (x > 6 * g || y > 6 * g) {
        return;
    }
    var startx = parseInt(round(x));
    var starty = parseInt(round(y));
    if (a[Math.floor(starty / g)][Math.floor(startx / g)] === false) {
        placePixel6(startx, starty);
        a[Math.floor(starty / g)][Math.floor(startx / g)] = true;
    } else {
        removePixel6(startx, starty);
        a[Math.floor(starty / g)][Math.floor(startx / g)] = false;
    }
}
function removePixel6(x, y) {
    canvasG.remove(rect[Math.floor(y / g)][Math.floor(x / g)]);
    canvasG.renderAll();
}

function placePixel6(x, y) {
    rect[Math.floor(y / g)][Math.floor(x / g)] = new fabric.Rect({left: x, top: y, width: g, height: g, selectable: false});
    canvasG.add(rect[Math.floor(y / g)][Math.floor(x / g)]);
}

function round(x1) {
    var x = parseInt(x1);
    var i = 0;
    while (i < x) {
        i += g;
    }
    return i - g;
}



//Main canvas starts here
var canvas;
var groupGrid;
var gridWidth;
var gridHeight;
function initMain() {
    canvas = new fabric.CanvasWithViewport('mCanvas');//getCanvas();
    //canvas.selectable=false;
    g = 10;//parseInt(document.getElementById("gSize").value);
    canvas.selection = false;
    gridWidth = Math.ceil(canvas.width / g);
    gridHeight = Math.ceil(canvas.height / g);
    mainFlag = new Array(gridHeight);
    mainPixel = new Array(gridHeight);
    for (var i = 0; i < gridHeight; i++) {
        mainFlag[i] = new Array(gridWidth);
    }
    for (var i = 0; i < gridHeight; i++) {
        for (var j = 0; j < gridWidth; j++) {
            mainFlag[i][j] = false;
        }
    }
    for (var i = 0; i < gridHeight; i++) {
        mainPixel[i] = new Array(gridWidth);
    }
}
function getCanvas() {
    return canvas;
}


var pixelFlag = false;
function pixelRouter() {
    if (pixelFlag === false) {
        createGrid();
        pixelFlag = true;
    } else {
        unPixel();
        pixelFlag = false;
    }
}
function unPixel() {
    canvas.off('mouse:down', myDown, false);
    canvas.off('mouse:move', myMove, false);
    canvas.off('mouse:up', myUp, false);
}
function gridMain() {
    groupGrid = new fabric.Group();
    for (var i = -0.95; i < canvas.width; i += g) {
        var line = new fabric.Line([i, 0, i, canvas.height], {stroke: "black", strokeWidth: 0.1, left: i, top: 0});
        groupGrid.add(line);
    }
    for (var i = -0.95; i < canvas.height; i += g) {
        var line = new fabric.Line([0, i, canvas.width, i], {stroke: "black", strokeWidth: 0.1, left: 0, top: i});
        groupGrid.add(line);
    }
    canvas.add(groupGrid);
}
function removeGrid() {
    canvas.remove(groupGrid);
}

var mainFlag;
var mainPixel;

function createGrid() {
    canvas.on('mouse:down', myDown, false);
    canvas.on('mouse:move', myMove, false);
    canvas.on('mouse:up', myUp, false);

    for (var i = 0; i < gridHeight; i++) {
        for (var j = 0; j < gridWidth; j++) {
            mainPixel[i][j] = mainPixel[i][j] = new fabric.Rect({left: j * g, top: i * g, width: g, height: g, selectable: false});
        }
    }
}

var downFlag = false;

function myDown(o) {
    var pointer = canvas.getPointer(o.e);
    var x = pointer.x;
    var y = pointer.y;
    var startx = parseInt(round1(x));
    var starty = parseInt(round1(y));
    downFlag = true;
    if (mainFlag[Math.floor(starty / g)][Math.floor(startx / g)] === false) {
        placePixel(startx, starty);
        mainFlag[Math.floor(starty / g)][Math.floor(startx / g)] = true;
    } else {
        removePixel(startx, starty);
        mainFlag[Math.floor(starty / g)][Math.floor(startx / g)] = false;
    }
}
function removePixel(x, y) {
    canvas.remove(mainPixel[Math.floor(y / g)][Math.floor(x / g)]);
    canvas.renderAll();
}

function placePixel(x, y) {
    //mainPixel[Math.floor(y/g)][Math.floor(x/g)]=new fabric.Rect({left:x,top:y,width:g,height:g,selectable:false});
    canvas.add(mainPixel[Math.floor(y / g)][Math.floor(x / g)]);
}

function round1(x1) {
    var x = parseInt(x1);
    var i = 0;
    while (i < x) {
        i += g;
    }
    return i - g;
}

function myMove(o) {
    var pointer = canvas.getPointer(o.e);
    var x = pointer.x;
    var y = pointer.y;
    var startx = parseInt(round1(x));
    var starty = parseInt(round1(y));
    if (downFlag === true) {
        if (mainFlag[Math.floor(starty / g)][Math.floor(startx / g)] === false) {
            mainFlag[Math.floor(starty / g)][Math.floor(startx / g)] = true;
            placePixel(startx, starty);
        }
    }
}
function myUp() {
    downFlag = false;
}

var temp;
var temp2;
var tempCanvas;
var checkFlag = false;
function checkRouter() {
    if (checkFlag === false) {
        checkout();
    } else {
        unCheck();
    }
}
function unCheck() {
    canvas.off('mouse:down', getXY, false);
    canvas.on('mouse:down', myDown, false);
    canvas.on('mouse:move', myMove, false);
    canvas.on('mouse:up', myUp, false);
}
function checkOut() {
    temp = new Array(gridHeight);
    for (var i = 0; i < gridHeight; i++) {
        temp[i] = new Array(gridWidth);
    }
    for (var i = 0; i < gridHeight; i++) {
        for (var j = 0; j < gridWidth; j++) {
            temp[i][j] = false;
        }
    }
    canvas.off('mouse:down', myDown, false);
    canvas.off('mouse:move', myMove, false);
    canvas.off('mouse:up', myUp, false);
    canvas.on('mouse:down', getXY, false);
    canvas.renderAll();
}
function getXY(o) {
    temp2 = mainFlag.slice();
    var pointer = canvas.getPointer(o.e);
    var x = pointer.x;
    var y = pointer.y;
    var startx = parseInt(round1(x)) / g;
    var starty = parseInt(round1(y) / g);
    var xx = getX(startx, starty);
    var yy = getY(startx, starty);
    var ww = sWidth(startx, starty);
    var hh = sHeight(startx, starty);
    applyPattern(xx, yy, ww, hh);
}

function getX(x, y) {
    var wi = gridWidth - 1;
    for (var i = y; i >= 0; i--) {
        for (var j = x; j >= 0; j--) {
            if (mainFlag[i][j] === true) {
                temp[i][j] = true;
                if (j < wi) {
                    wi = j;
                }
                if (j === 0) {
                    wi = 0;
                }
            } else {
                break;
            }
        }
    }
    for (var i = y; i < gridHeight; i++) {
        for (var j = x; j >= 0; j--) {
            if (mainFlag[i][j] === true) {
                temp[i][j] = true;
                if (j < wi) {
                    wi = j;
                }
                if (j === 0) {
                    wi = 0;
                }
            } else {
                break;
            }
        }
    }
    return wi;
}

function getY(x, y) {
    var hi = gridHeight - 1;
    ;
    for (var i = x; i >= 0; i--) {
        for (var j = y; j >= 0; j--) {
            if (mainFlag[j][i] === true) {
                temp[j][i] = true;
                if (hi > j) {
                    hi = j;
                }
                if (j === 0) {
                    hi = 0;
                }
            } else {
                break;
            }
        }
    }
    for (var i = x; i < gridWidth; i++) {
        for (var j = y; j >= 0; j--) {
            if (mainFlag[j][i] === true) {
                temp[j][i] = true;
                if (hi > j) {
                    hi = j;
                }
                if (j === 0) {
                    hi = 0;
                }
            } else {
                break;
            }
        }
    }
    return hi;
}

function sWidth(x, y) {
    var wi = 0;
    for (var i = y; i < gridHeight; i++) {
        for (var j = x; j < gridWidth; j++) {
            try {
                if (mainFlag[i][j] === true) {
                    temp[i][j] = true;
                    if (j > wi) {
                        wi = j;
                    }
                    if (j === mainFlag[i].length - 1) {
                        wi = i;
                    }
                } else {
                    break;
                }
            } catch (e) {
                wi = mainFlag.length - 1;
            }
        }
    }
    for (var i = y; i >= 0; i--) {
        for (var j = x; j < gridWidth; j++) {
            try {
                if (mainFlag[i][j] === true) {
                    temp[i][j] = true;
                    if (j > wi) {
                        wi = j;
                    }
                    if (j === mainFlag[i].length - 1) {
                        wi = i;
                    }
                } else {
                    break;
                }
            } catch (e) {
                wi = mainFlag.length - 1;
            }
        }
    }
    return wi + 1;
}

function sHeight(x, y) {
    var hi = 0;
    for (var i = x; i < gridWidth; i++) {
        for (var j = y; j < gridHeight; j++) {
            if (mainFlag[j][i] === true) {
                temp[j][i] = true;
                if (hi < j) {
                    hi = j;
                }
                if (j === gridHeight) {
                    hi = i;
                }
            } else {
                break;
            }
        }
    }
    for (var i = x; i >= 0; i--) {
        for (var j = y; j < gridHeight; j++) {
            if (mainFlag[j][i] === true) {
                temp[j][i] = true;
                if (hi < j) {
                    hi = j;
                }
                if (j === gridHeight) {
                    hi = i;
                }
            } else {
                break;
            }
        }
    }
    return hi;
}

function applyPattern(x, y, w, h) {
    preserveBorder();
    for (var i = y, k = 0; i <= h; i++, k++) {
        for (var j = x, l = 0; j < w; j++, l++) {
            if (a[k % 6][l % 6] === true && temp[i][j] === true) {
                canvas.remove(mainPixel[i][j]);
                mainFlag[i][j] = false;
            }
        }
    }
}

function preserveBorder() {
    for (var i = 0; i < gridHeight; i++) {
        for (var j = 0; j < gridWidth; j++) {
            if (temp[i][j] === true) {
                temp[i][j] = false;
                break;
            }
        }
    }
    for (var j = 0; j < gridWidth; j++) {
        for (var i = 0; i < gridHeight; i++) {
            if (temp[i][j] === true) {
                temp[i][j] = false;
                break;
            }
        }
    }
    for (var i = gridHeight - 1; i >= 0; i--) {
        for (var j = gridWidth - 1; j >= 0; j--) {
            if (temp[i][j] === true) {
                temp[i][j] = false;
                break;
            }
        }
    }
    for (var j = gridWidth - 1; j >= 0; j--) {
        for (var i = gridHeight - 1; i >= 0; i--) {
            if (temp[i][j] === true) {
                temp[i][j] = false;
                break;
            }
        }
    }

}

function delectCanvas() {
    var obj = document.getElementById('pannel');
    obj.innerHTML = "canvas Deleted";
}


function clearMain() {
    for (var i = 0; i < gridHeight; i++) {
        for (var j = 0; j < gridWidth; j++) {
            mainFlag[i][j] = false;
        }
    }
}


