app.factory('newOrderAndCatalogService', function($rootScope) {
    var catalogNewOrderShared = {};
    catalogNewOrderShared.category = "";
    catalogNewOrderShared.type = "";

    catalogNewOrderShared.setCategoryAndType = function(category, type) {
        this.category = category;
        this.type = type;
        this.setValues();
    };

    catalogNewOrderShared.setValues = function() {
        $rootScope.$broadcast('setCategoryAndCatalogValue');
    };

    return catalogNewOrderShared;

});