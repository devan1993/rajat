var canvas;
$("#canvasPencil").click(function() {
    alert()
});
function startCanvasStudio() {
    canvas = getCanvas(); // new fabric.CanvasWithViewport('mCanvas');
    var lineCol = document.getElementById("lineColor").value,
            shapeCol = document.getElementById("shapeColor").value,
            grid = 10,
            line,
            group;
    //Pencil Code Start
    $("#canvasPencil").click(function() {

        canvas.isDrawingMode = !canvas.isDrawingMode;
        if ($("input[type=button]").is(':disabled'))
            $("input[type=button]").prop("disabled", false)
        else
            $("input[type=button]").prop("disabled", true);
        $("#pencil").prop("disabled", false);
    });
    $("#comSplit").click(function() {
        if (document.getElementById('comSplit').src == "http://localhost:8084/Weave_Version2.0/Assets/CSS/icon/Combine.png") {
            document.getElementById('comSplit').src = "http://localhost:8084/Weave_Version2.0/Assets/CSS/icon/split.png";
        }
        else {
            this.src = "http://localhost:8084/Weave_Version2.0/Assets/CSS/icon/Combine.png"
        }
    });
    $("#lineWidth").change(function() {
        canvas.freeDrawingBrush.width = parseInt(this.value);
        document.getElementById("lWidth").value = parseInt(this.value);
        canvas.getActiveObject().strokeWidth = parseInt(this.value);
        canvas.renderAll();
    });
    $("#lineColor").change(function() {
        canvas.freeDrawingBrush.color = this.value;
        canvas.getActiveObject().stroke = this.value;
        lineCol = this.value;
        canvas.renderAll();
    });
    //Pencil Code End

    //Background Color Start
    $("#backColor").change(function() {
        canvas.backgroundColor = this.value;
        canvas.renderAll();
    });
    //Background Color End

    //Shape Color Start
    $("#shapeColor").change(function() {
        shapeCol = this.value;
        canvas.getActiveObject().fill = '' + shapeCol;
        canvas.renderAll();
    });
    //Shape Color End

    //Line Tool Start
//    $("#shirt").click(function() {
//       	var imgObj = new Image();
//	imgObj.src = "shirtdemosvg.svg";
//	imgObj.onload = function () {
//        var image = new fabric.Image(imgObj);
//         image.set({
//            angle: 0,
//            padding: 10,
//            cornersize:10,
//             height:200
//            //widhth:100
//        });
//    canvas.centerObject(image);
//        canvas.add(image);
//        canvas.renderAll();
//        };
//    });
//
//    $("#shirt").click(function() {
//        canvas.clear();
//        clearMain();
//        var imgObj = new Image();
//        imgObj.src = "icon/shirtdemo.png";
//        imgObj.onload = function() {
//            var image = new fabric.Image(imgObj);
//            image.set({
//                angle: 0,
//                padding: 10,
//                cornersize: 10,
//                height: 200
//                        //  widhth:100
//            });
//            canvas.centerObject(image);
//            canvas.add(image);
//            canvas.renderAll();
//        };
//    });
    $("#shirt").click(function() {
        canvas.clear();
        clearMain();
        var imgObj = new Image();
        imgObj.src = "view/images/shirtdemo.png";
        imgObj.onload = function() {
            var image = new fabric.Image(imgObj);
            image.set({
                angle: 0,
                padding: 10,
                cornersize: 10,
                height: 200
                        //  widhth:100
            });
            canvas.centerObject(image);
            canvas.add(image);
            canvas.renderAll();
        };
    });
    $("#pant").click(function() {
        canvas.clear();
        clearMain();
        var imgObj = new Image();
        imgObj.src = "view/images/pantdemo.png";
        imgObj.onload = function() {
            var image = new fabric.Image(imgObj);
            image.set({
                angle: 0,
                padding: 10,
                cornersize: 10,
                height: 200
                        //  widhth:100
            });
            canvas.centerObject(image);
            canvas.add(image);
            canvas.renderAll();
        };
    });
    $("#kurti").click(function() {
        canvas.clear();
        clearMain();
        var imgObj = new Image();
        imgObj.src = "view/images/kurtidemo.png";
        imgObj.onload = function() {
            var image = new fabric.Image(imgObj);
            image.set({
                angle: 0,
                padding: 10,
                cornersize: 10,
                height: 200
                        // widhth:100
            });
            canvas.centerObject(image);
            canvas.add(image);
            canvas.renderAll();
        };
    });
    $("#leggings1").click(function() {
        canvas.clear();
        clearMain();
        var imgObj = new Image();
        imgObj.src = "view/images/leginsdemo1.png";
        imgObj.onload = function() {
            var image = new fabric.Image(imgObj);
            image.set({
                angle: 0,
                padding: 10,
                cornersize: 10,
                height: 200
                        //  widhth:100
            });
            canvas.centerObject(image);
            canvas.add(image);
            canvas.renderAll();
        };
    });
    $("#leggings2").click(function() {
        canvas.clear();
        clearMain();
        var imgObj = new Image();
        imgObj.src = "view/images/leginsdemo2.png";
        imgObj.onload = function() {
            var image = new fabric.Image(imgObj);
            image.set({
                angle: 0,
                padding: 10,
                cornersize: 10,
                height: 200
                        //  widhth:100
            });
            canvas.centerObject(image);
            canvas.add(image);
            canvas.renderAll();
        };
    });
    //Line Tool End

    //Circle Tool Start
    $("#addFCircle").click(function() {
        canvas.clear();
        clearMain();
        canvas.add(new fabric.Circle({
            radius: 20, fill: shapeCol, left: 50, top: 50}));
    });
    $("#addHCircle").click(function() {
        canvas.clear();
        clearMain();
        canvas.add(new fabric.Circle({
            radius: 20, fill: 'transparent', left: 70, top: 70, stroke: lineCol}));
    });
    //Circle Tool End

    //Rectangel Tool Start
    $("#addFRectangle").click(function() {
        canvas.clear();
        clearMain();
        canvas.add(new fabric.Rect({
            left: 100, top: 100, fill: shapeCol, width: 20, height: 20, angle: 45}));
    });
    $("#addHRectangle").click(function() {
        canvas.clear();
        clearMain();
        canvas.add(new fabric.Rect({
            left: 100, top: 100, fill: 'transparent', width: 20, height: 20, angle: 45, stroke: lineCol}));
    });
    //Rectangle Tool End

    //Pollygon Tool Start
    $("#addFPolygon").click(function() {
        canvas.clear();
        clearMain();
        canvas.add(new fabric.Polygon([{x: 185, y: 0}, {x: 250, y: 100}, {x: 385, y: 170}, {x: 0, y: 245}], {
            left: 220, top: 200, angle: -30, fill: shapeCol}));
    });
    $("#addHPolygon").click(function() {
        canvas.clear();
        clearMain();
        canvas.add(new fabric.Polygon([{x: 185, y: 0}, {x: 250, y: 100}, {x: 385, y: 170}, {x: 0, y: 245}], {
            left: 220, top: 200, angle: -30, fill: 'transparent', stroke: lineCol}));
    });
    //Pollygon Tool End

    //Remove Object Start
    $("#removeObject").click(function() {
        if (canvas.getActiveGroup()) {
            canvas.getActiveGroup().forEachObject(function(o) {
                canvas.remove(o);
            });
            canvas.discardActiveGroup().renderAll();
        } else {
            canvas.remove(canvas.getActiveObject());
            canvas.renderAll();
        }
    });
    //Remove Object End

    //Clear Canvas Start
    $("#clearCanvas").click(function() {
        canvas.clear();
        clearMain();
    });
    //Clear Canvas End

    //Grid Started
    function cGrid() {
        grid = document.getElementById('gridSize').value;
        group = new fabric.Group();
        for (var i = 0; i < (canvas.width / grid); i++) {
            line = new fabric.Line([i * grid, 0, i * grid, canvas.height], {stroke: 'black', selectable: false});
            group.add(line);
        }

        for (var i = 0; i < (canvas.height / grid); i++) {
            line = new fabric.Line([0, i * grid, canvas.width, i * grid], {stroke: 'black', selectable: false});
            group.add(line);
        }
        canvas.add(group);
        canvas.bringToFront(group);
    }
    $('#gridMode').change(function() {
        if ($("#gridMode").is(":checked")) {
            cGrid();
        } else {
            canvas.remove(group);
        }
    });
    //Grid End

//Shifting Started
    $("#shiftUp").click(function() {
        if (canvas.getActiveGroup()) {
            canvas.getActiveGroup().setTop(canvas.getActiveGroup().getTop() - grid);
        }
        else {
            canvas.getActiveObject().setTop(canvas.getActiveObject().getTop() - grid);
        }
        canvas.renderAll();
    });
    $("#shiftRight").click(function() {
        if (canvas.getActiveGroup()) {
            canvas.getActiveGroup().setLeft(canvas.getActiveGroup().getLeft() - (-grid));
        }
        else {
            canvas.getActiveObject().setLeft(canvas.getActiveObject().getLeft() - (-grid));
        }
        canvas.renderAll();
    });
    $("#shiftDown").click(function() {
        if (canvas.getActiveGroup()) {
            canvas.getActiveGroup().setTop(canvas.getActiveGroup().getTop() - (-grid));
        } else
            canvas.getActiveObject().setTop(canvas.getActiveObject().getTop() - (-grid));
        canvas.renderAll();
    });
    $("#shiftLeft").click(function() {
        if (canvas.getActiveGroup()) {
            canvas.getActiveGroup().setLeft(canvas.getActiveGroup().getLeft() - grid);
        } else
            canvas.getActiveObject().setLeft(canvas.getActiveObject().getLeft() - grid);
        canvas.renderAll();
    });
//Shifting Ended

    //Position Started
    $("#sendToBack").click(function() {
        canvas.sendToBack(canvas.getActiveObject());
    });
    $("#sendBackward").click(function() {
        canvas.sendBackwards(canvas.getActiveObject());
    });
    $("#bringToFront").click(function() {
        canvas.bringToFront(canvas.getActiveObject());
        if ($("#gridMode").is(":checked")) {
            canvas.bringToFront(group);
        }
    });
    $("#bringForward").click(function() {
        canvas.bringForward(canvas.getActiveObject());
        if ($("#gridMode").is(":checked")) {
            canvas.bringToFront(group);
        }
    });
    //Position End
    var flagg = false;
    //Filling Grid Code Start
    $("#pixelMode").change(function() {
        if ($("#pixelMode").is(":checked")) {
            flagg = true;
            canvas.deactivateAllWithDispatch();
            canvas.selection = false;
            canvas.forEachObject(function(o) {
                o.selectable = false;
            });
        }
        else {
            flagg = false;
            canvas.selection = true;
            canvas.forEachObject(function(o) {
                o.selectable = true;
            });
        }
    });
    var notEmpty = [];
    var currPlayer = 0;
    var Players = {
        1: {
            name: 'Player 1',
            color: 'rgba(0,0,200,0.5)'
        },
        2: {
            name: 'Player 2',
            color: 'rgba(200,0,0,0.5)'
        }
    };

    function getNextPlayer() {
        currPlayer = currPlayer + 1 > 2 ? 1 : 2;
        return currPlayer;
    }
    function Cell(x, y) {
        this.left = Math.floor(x / grid);
        this.top = Math.floor(y / grid);
        this.valueOf = function() {
            return [this.left, this.top].join(",");
        };
    }
    function isEmpty(cell) {
        return !notEmpty.hasOwnProperty(cell.valueOf());
    }
    function push(cell) {
        if (flagg === true) {
            var player = Players[getNextPlayer()];
            var data = {};
            data[cell.valueOf] = player;
            notEmpty.push(data);
            //draw cell

            var rect = new fabric.Rect({
                width: grid, height: grid, left: cell.left * grid, top: cell.top * grid, angle: 0,
                stroke: 'white', strokeWidth: 1,
                // fill: player.color,
                selectable: false
            });
            canvas.add(rect);
            checkWin();
        }
    }

    function checkWin() {
        var top, left;
        // check vertical
        for (top = 0; top < 3; top++) {
            var c = 0;
            for (left = 0; left < 3; left++) {
                var cell = new Cell(left * grid, top * grid);
                if (!isEmpty(cell))
                    c++;
            }
        }
    }
    falg = false;
//    //
//    canvas.on('mouse:down', function(event) {
//        if (flagg === true) {
//            var pointer = canvas.getPointer(event.e);
//            var coord = new Cell(pointer.x, pointer.y);
//            if (isEmpty(coord)) {
//                push(coord);
//            }
//            console.log(pointer.x,pointer.y);
//            falg = true;
//        }
//    });
//
//    canvas.on('mouse:move', function(event) {
//        if (flagg == true && falg == true) {
//            var pointer = canvas.getPointer(event.e);
//            var coord = new Cell(pointer.x, pointer.y);
//            if (isEmpty(coord)) {
//                push(coord);
//            }
//        }
//    });
//    canvas.on('mouse:up', function(event) {
//        falg = false;
//    });

//Edit Mode Start
    $("#editCan").click(function() {
        $(this).addClass("active");
        $("#editCan").not(this).removeClass("active");
        canvas.isDrawingMode = false;
        canvas.isGrabMode = false;
        return false;
    })
    //Edit Mode End

    //GrabMode Start
    $("#grabCan").click(function() {
        $(this).addClass("active");
        $("grabCan").not(this).removeClass("active");
        canvas.isDrawingMode = false;
        canvas.isGrabMode = true;
        return false;
    })
    //Grab Mode End

    //Zoom In Start
    $("#zoomICan").click(function() {
        canvas.setZoom(canvas.viewport.zoom * 1.1);
        return false;
    })
    //Zoom In End

    //Zoom Out Start
    $("#zoomOCan").click(function() {
        canvas.setZoom(canvas.viewport.zoom / 1.1);
        return false;
    })
    //Zoom Out End



    $("#addTriangle").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 3;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 10,
            left: 20,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addSquare").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 4;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addPolygon").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 5;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addHexagon").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 6;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addPentagon").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 7;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addOctagon").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 8;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addNonagon").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 9;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
    $("#addDecagon").click(function() {
        var angle = Math.PI / 4;
        var coordinates = [],
                radius = Math.sqrt(Math.pow(((-50)), 2) + Math.pow(((-25)), 2)),
                index = 0;
        var sides = 10;
        for (index = 0; index < sides; index++) {
            coordinates.push({x: (-50) + radius * Math.cos(angle), y: (-25) - radius * Math.sin(angle)});
            angle += (2 * Math.PI) / sides;
        }

        var thesePoints = [{x: -90, y: 00}, {x: 50, y: 00}];
        //var thesePoints = [{x: 90, y: -55}, {x: 50, y: -25}, {x: 70, y: 25}];
        var myPolygon = new fabric.Polygon(coordinates, {
            top: 100,
            left: 250,
            fill: '#999999',
            stroke: '#000000',
            strokeWidth: 1,
        });
        canvas.add(myPolygon);
    });
}
;
