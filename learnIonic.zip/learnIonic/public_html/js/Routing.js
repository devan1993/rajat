
app.config(function($stateProvider, $urlRouterProvider) {

    $stateProvider
            .state('home', {
        url: "/",
        templateUrl: "views/home.html",
        controller: "signUpController"
    })
    .state('signUp', {
        url: "/signUp",
        templateUrl: "views/signUp.html",
        controller: "signUpController"
    });
    $urlRouterProvider.otherwise("/");
});