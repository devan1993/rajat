var app = angular.module('learnIonic', ['ionic', 'ngRoute', 'ui.router'])
        .run(function($rootScope) {
    $rootScope.category = "";
    $rootScope.type = "";
});
app.controller('signUpController', function($scope, $ionicPopup, $timeout, $location, $http) {
    console.log("signUpController");
});


